Team Black Miner was created by a group of nordic black ops in the cryptocurrency scene.
TBMiner maintains a leading position in the mining coins like Ethereum, Ethereum Classic, Zilliqa, Vertcoin with the lowest dev fee 0.5-1%

(See https://github.com/sp-hash/TeamBlackMiner for newest updates and documentation.)

Miner requirements
Windows 10 or linux. AMD or NVIDIA grapic cards.
NVIDIA: A driver that can handle Cuda 11.2 and 11.4 code.
	NVIDIA card with compute 5.0 or newer.

AMD: Adrenaline drivers
     For optimal performance and stats, set the GPU in compute mode.

windows:
Visual studio 2015-2019 Redistributable Package
Run ansicolor.reg script for colors
Latest NVIDIA driver, or newer than v460.89

Support for older cuda versions, windows 8.1 and 7 has been depricated.

Miner Features:
+ Commission is charged continuously, and not in intervals (as in most miners), which has a positive effect on the user's profitability on PPLNS pools
+ Verifying Shares on processor, warning when GPU overclocking is very high for Ethash, Etcash, helps to overclock GPU without errors
+ DAG caching if the GPU has enough memory, DAG files are not recomputed when switching to another algorithm when mining Ethash + Zilliqa or Nicehash. (NVIDIA only)
+ Temperature control and stop the GPU in case of overheating (NVIDIA only)
+ Mechanism to restore lost connection with pool
+ Support secure connections
+ Support SOCKS5 proxy
+ Informative and readable tabular statistics output to console
+ Display of detailed information on each device (temperature, power consumption, cooler load, memory frequency, processor frequency, energy efficiency)
+ Parallel output of information to console and to file on disk

Example scripts are included in the archive

Available command line options:

-h --help                   (Prints available command line options)
-V --version                (Prints version information)
-c --configfile             (Set filename and path for configuration file)
-L --log                    (Enable logging)
-l --logfile                (Set name for logfile)
-i --ip                     (Set ip address for pool)
-H --hostname               (Set hostname for pool)
-p --port                   (Set port number for pool)
-x --ssl-port               (Set SSL port number for SSL connections)
-W --wallet                 (Set your wallet address. Might be a username for some pools)
-w --worker-name            (Set your pool worker name)
-P --server-passwd          (Set your pool server password)
-o --http-path              (Set a path to specify http path for pool if needed)
-s --ssl                    (Use a SSL connection to pool)
-S --ssl-verify             (Check pools ssl certificate integrity)
-C --ssl-cert               (Set a pem file to verify pools ssl cert integrity)       
-n --no-redirect            (No redirect means no connection forwarding and no stratum reconnect to new server)  
-r --retries                (Set number of retry attempts for connecting to pool)
-y --retry-pause            (Set retry pause between connection attempts if pool is not responding)
-t --timeout                (Set timeout in seconds. Used for connecting and socket timeout)
-a --algo                   (Set algorihtm, supported algorithms is ethash, etchash and zil)
-D --list-devices           (List all rig GPU devices. Useful for setting up particular devices)  
-A --auto-detect            (Autodetect means all Nvidia cards use Cuda and all Amd cards use OpenCL)
-Y --cl-devices [,]         (Set a comma separated array of GPU devices ids for OpenCL to use)
-U --cuda-devices [,]       (Set a comma separated array of GPU device ids for Nvidia Cuda devices to be used)
-z --cl-all-devices         (Use OpenCl for all devices)
-Z --cuda-all-devices       (Use all Nvidia Cuda devices)
-T --templimit [,]          (Set a comma separated array of GPU device ids)    
-g --templimit-sleep        (Set GPU sleep for seconds when temperature limit have been exceeded)
-f --fan-speed-min          (Set minimum fan speed in RPM to warn if fan is not working properly)
-e --electricity-cost       (Set cost per kWh)
-u --electricity-currency   (Set currency type for stats)
-v --no-verbose             (Less output) 
-I --no-ansi                (Disable ANSI console output)
-B --no-stats               (Disable statistics)
-N --no-cpu                 (Lower CPU usage)
-b --amd-only               (Run with only Amd devices)
-G --nvidia-only            (Run with only Nvidia devices)
-K --dagintensity value [,] (One number set for all, or Set a comma separated array of GPU devices intensity)
                            (Default Nvidia=0/Amd=0 Valid values 1-9) (1 low, 9 high) 
-E --xintensity value [,]   (One number set for all,Set a comma separated array of GPU devices intensity)
                            (Default Nvidia=400/Amd=-1 (calculate dynamic) Valid values 1-xxxxx)
-u --tweak value [,]        (One number set for all,Set a comma separated array of GPU devices tweak)
                            (Nvidia only Valid values 0-7) (0 default)
-j --lock-cclock [[,],[,]]  (Set an array of min and max core clock values for cuda devices)
-m --lock-mclock [[,],[,]]  (Set an array of min and max memory clock values for cuda devices)
-M --power-limit [,]	    (set powerlimit)
-d --api                    (Enable API)
-F --api-ip                 (Set ip address)
-R --api-port               (Set port number)


Supported algorithms and developer commission:

ETH, ethash              0.5%
ETC, etchash             0.5%
ZIL standalone           1.0%
Vertcoin                 1.0%
ETH+ZIL, ethash          0.5%
ETC+ZIL, etchash         0.5%
VTC+ZIL                  1.0%



